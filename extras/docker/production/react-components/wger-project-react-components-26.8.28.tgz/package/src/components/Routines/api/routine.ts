import { getExercisesByIds } from "@/components/Exercises/api/exercise";
import { Exercise } from "@/components/Exercises/models/exercise";
import { getRoutineRepUnits, getRoutineWeightUnits } from "@/components/Routines/api/workoutUnits";
import { attachExercises } from "@/components/Routines/api/workoutLogs";
import { Day } from "@/components/Routines/models/Day";
import { RoutineStatsData, RoutineStatsDataAdapter } from "@/components/Routines/models/LogStats";
import { Routine } from "@/components/Routines/models/Routine";
import { RoutineDayData } from "@/components/Routines/models/RoutineDayData";
import { RoutineLogData, RoutineLogDataAdapter } from "@/components/Routines/models/RoutineLogData";
import { ResponseType } from "@/core/api/responseType";
import { ApiPath } from "@/core/lib/consts";
import { makeHeader, makeUrl } from "@/core/lib/url";
import axios from 'axios';

export const ROUTINE_API_STRUCTURE_PATH = 'structure';
export const ROUTINE_API_LOGS_PATH = 'logs';
export const ROUTINE_API_STATS_PATH = 'stats';
export const ROUTINE_API_ALL_ITERATION_DISPLAY = 'date-sequence-display';


/*
 * Processes a routine with all sub-objects
 */
export const processRoutine = async (id: number): Promise<Routine> => {

    const response = await axios.get(
        makeUrl(ApiPath.ROUTINE, { id: id }),
        { headers: makeHeader() }
    );
    const routine = Routine.fromJson(response.data);

    const responses = await Promise.all([
        getRoutineRepUnits(),
        getRoutineWeightUnits(),
        getRoutineDayDataAllIterations(id),
        getRoutineStructure(id),

    ]);
    const repsUnits = responses[0];
    const weightUnits = responses[1];
    const dayDataAllIterations = responses[2];
    const dayStructure = responses[3];


    // Collect all unique exercise IDs and load the data in bulk.
    //
    // The structure is the source of truth here: a day whose first iteration falls
    // past the routine's end date has no entry in the day data, but its slots are
    // still edited and displayed.
    const exerciseIds = new Set<number>();
    for (const day of dayStructure) {
        for (const slot of day.slots) {
            for (const slotEntry of slot.entries) {
                exerciseIds.add(slotEntry.exerciseId);
            }
        }
    }
    const exercises = await getExercisesByIds(Array.from(exerciseIds));
    const exerciseMap: { [id: number]: Exercise } = {};
    exercises.forEach(exercise => {
        exerciseMap[exercise.id!] = exercise;
    });

    // Collect and load all exercises for the workout
    for (const dayData of dayDataAllIterations) {
        for (const slotData of dayData.slots) {
            for (const setData of slotData.setConfigs) {
                setData.exercise = exerciseMap[setData.exerciseId];
                if (setData.repetitionsUnitId !== null) {
                    setData.repetitionsUnit = repsUnits.find(r => r.id === setData.repetitionsUnitId) ?? null;
                }

                if (setData.weightUnitId !== null) {
                    setData.weightUnit = weightUnits.find(w => w.id === setData.weightUnitId) ?? null;
                }
            }

            for (const exerciseId of slotData.exerciseIds) {
                // Skip exercises that could not be loaded so the array stays free of
                // undefined holes that the UI would choke on
                const exercise = exerciseMap[exerciseId];
                if (exercise !== undefined) {
                    slotData.exercises?.push(exercise);
                }
            }
        }
    }

    for (const day of dayStructure) {
        for (const slot of day.slots) {
            for (const slotEntry of slot.entries) {
                slotEntry.exercise = exerciseMap[slotEntry.exerciseId];

                if (slotEntry.repetitionUnitId !== null) {
                    slotEntry.repetitionUnit = repsUnits.find(r => r.id === slotEntry.repetitionUnitId) ?? null;
                }

                if (slotEntry.weightUnitId !== null) {
                    slotEntry.weightUnit = weightUnits.find(w => w.id === slotEntry.weightUnitId) ?? null;
                }
            }
        }
    }

    routine.dayData = dayDataAllIterations;
    routine.days = dayStructure;

    return routine;
};


/*
 * Retrieves all routines
 *
 * Note: this returns all the data, including all sub-objects
 */
export const getRoutines = async (): Promise<Routine[]> => {
    const url = makeUrl(ApiPath.ROUTINE, { query: { 'is_public': false } });
    const response = await axios.get<ResponseType<Routine>>(
        url,
        { headers: makeHeader() }
    );

    const out: Routine[] = [];
    for (const routineData of response.data.results) {
        out.push(await processRoutine(routineData.id!));
    }
    return out;
};

/*
 * Returns the current active routine
 *
 * Note that at the moment this is simply the newest one
 */
export const getActiveRoutine = async (): Promise<null | Routine> => {
    const url = makeUrl(ApiPath.ROUTINE, { query: { 'limit': '1', 'is_template': false } });

    const response = await axios.get<ResponseType<Routine>>(
        url,
        { headers: makeHeader() }
    );

    if (response.data.count === 0) {
        return null;
    }

    return await processRoutine(response.data.results[0].id!);
};

export const getRoutine = async (id: number): Promise<Routine> => {
    return await processRoutine(id);
};

/*
 * Retrieves all routines
 *
 * Note: strictly only the routine data, no days or any other sub-objects
 */
export const getRoutinesShallow = async (): Promise<Routine[]> => {
    const url = makeUrl(ApiPath.ROUTINE, { query: { 'is_public': false } });
    const response = await axios.get<ResponseType<Routine>>(
        url,
        { headers: makeHeader() }
    );

    return response.data.results.map(routineData => Routine.fromJson(routineData)).filter(routine => routine.isNotTemplate);
};

export const getPrivateTemplatesShallow = async (): Promise<Routine[]> => {
    const url = makeUrl(ApiPath.PRIVATE_TEMPLATE);
    const response = await axios.get<ResponseType<Routine>>(
        url,
        { headers: makeHeader() }
    );

    return response.data.results.map(routineData => Routine.fromJson(routineData));
};

export const getPublicTemplatesShallow = async (): Promise<Routine[]> => {
    const url = makeUrl(ApiPath.PUBLIC_TEMPLATE);
    const response = await axios.get<ResponseType<Routine>>(
        url,
        { headers: makeHeader() }
    );

    return response.data.results.map(routineData => Routine.fromJson(routineData));
};

export const addRoutine = async (routine: Routine): Promise<Routine> => {
    const response = await axios.post(
        makeUrl(ApiPath.ROUTINE,),
        routine.toJson(),
        { headers: makeHeader() }
    );

    return Routine.fromJson(response.data);
};

export const editRoutine = async (routine: Routine): Promise<Routine> => {
    const response = await axios.patch(
        makeUrl(ApiPath.ROUTINE, { id: routine.id! }),
        routine.toJson(),
        { headers: makeHeader() }
    );

    return Routine.fromJson(response.data);
};


export const getRoutineDayDataAllIterations = async (routineId: number): Promise<RoutineDayData[]> => {
    const response = await axios.get(
        makeUrl(ApiPath.ROUTINE, { id: routineId, objectMethod: ROUTINE_API_ALL_ITERATION_DISPLAY }),
        { headers: makeHeader() }
    );

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return response.data.map((data: any) => RoutineDayData.fromJson(data));
};

export const getRoutineStructure = async (routineId: number): Promise<Day[]> => {
    const response = await axios.get(
        makeUrl(ApiPath.ROUTINE, { id: routineId, objectMethod: ROUTINE_API_STRUCTURE_PATH }),
        { headers: makeHeader() }
    );

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return response.data.days.map((data: any) => Day.fromJson(data));
};

export const getRoutineLogData = async (routineId: number): Promise<RoutineLogData[]> => {
    const response = await axios.get(
        makeUrl(ApiPath.ROUTINE, { id: routineId, objectMethod: ROUTINE_API_LOGS_PATH }),
        { headers: makeHeader() }
    );

    const adapter = new RoutineLogDataAdapter();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const logData: RoutineLogData[] = response.data.map((data: any) => adapter.fromJson(data));

    // The exercises can't be taken from the routine structure, a log can point to
    // one that is not (or no longer) part of it, e.g. after a swap or when the
    // logs were imported from another app.
    await attachExercises(logData.flatMap(data => data.logs));

    return logData;
};

export const getRoutineStatisticsData = async (routineId: number): Promise<RoutineStatsData> => {
    const response = await axios.get(
        makeUrl(ApiPath.ROUTINE, { id: routineId, objectMethod: ROUTINE_API_STATS_PATH }),
        { headers: makeHeader() }
    );

    return new RoutineStatsDataAdapter().fromJson(response.data);
};

export type SpreadsheetKind = 'csv' | 'xlsx';
export type ImportMode = 'create' | 'update';

export interface ImportRequest {
    file: File;
    mode: ImportMode;
    // Only for update, the owned routine the file is applied to
    routineId: number | null;
    dropUnsupported: boolean;
}

type ImportCounts = { days: number, slots: number, entries: number };

export type ImportExerciseMatch =
    | { how: 'id' | 'uuid' | 'name', id: number, name: string }
    | { how: 'mismatch', id: number }
    | { how: 'ambiguous', candidates: { id: number, name: string }[] }
    | { how: 'unresolved' };

// The import-preview response (and the body of a 400/409 import-confirm)
export interface ImportPreview {
    ok: boolean;
    plan_hash: string;
    mode: ImportMode;
    routine: { id: number | null, name: string, description: string, start: string, end: string } | null;
    rows: { row: number, status?: 'ok' | 'error', exercise: ImportExerciseMatch | null }[];
    errors: { row: number | null, column: string | null, message: string }[];
    diff: {
        create: ImportCounts,
        update: ImportCounts,
        delete: ImportCounts,
        blocked_deletes: { kind: string, id: number, reason: string }[],
    };
    unsupported_dropped: { row: number, codes: string[] }[];
    detail?: string;
}

/*
 * Downloads a routine (or, without an id, the empty import template) as a CSV or XLSX file
 */
export const downloadRoutineSpreadsheet = async (kind: SpreadsheetKind, routineId?: number): Promise<void> => {
    const url = routineId === undefined
        ? makeUrl(ApiPath.ROUTINE, { objectMethod: 'import-template', query: { file: kind } })
        : makeUrl(ApiPath.ROUTINE, { id: routineId, objectMethod: 'export', query: { file: kind } });
    const response = await axios.get<Blob>(url, { headers: makeHeader(), responseType: 'blob' });

    const link = document.createElement('a');
    link.href = URL.createObjectURL(response.data);
    link.download = `${routineId === undefined ? 'routine-template' : `routine-${routineId}`}.${kind}`;
    link.click();
    URL.revokeObjectURL(link.href);
};

const importForm = (request: ImportRequest, planHash?: string) => {
    const form = new FormData();
    form.append('file', request.file);
    form.append('mode', request.mode);
    if (request.mode === 'update') {
        form.append('routine', String(request.routineId ?? ''));
    }
    form.append('drop_unsupported', String(request.dropUnsupported));
    if (planHash !== undefined) {
        form.append('plan_hash', planHash);
    }
    return form;
};

const multipartHeader = () => ({ ...makeHeader(), 'Content-Type': 'multipart/form-data' });

/*
 * Checks an uploaded file, nothing is written
 */
export const previewRoutineImport = async (request: ImportRequest): Promise<ImportPreview> => {
    const response = await axios.post<ImportPreview>(
        makeUrl(ApiPath.ROUTINE, { objectMethod: 'import-preview' }),
        importForm(request),
        { headers: multipartHeader() }
    );
    return response.data;
};

/*
 * Applies a previewed file in one transaction. Rejects with 400 (the plan has
 * errors) or 409 (file or routine changed since the preview), nothing written
 */
export const confirmRoutineImport = async (request: ImportRequest, planHash: string): Promise<{ id: number }> => {
    const response = await axios.post<{ id: number }>(
        makeUrl(ApiPath.ROUTINE, { objectMethod: 'import-confirm' }),
        importForm(request, planHash),
        { headers: multipartHeader() }
    );
    return response.data;
};
