import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Day } from "@/components/Routines/models/Day";
import { addDay, deleteDay, editDay } from "@/components/Routines/api/day";
import { QueryKey, } from "@/core/lib/consts";


export const useEditDayQuery = (routineId: number) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (day: Day) => editDay(day),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: [QueryKey.ROUTINE_DETAIL, routineId] })
    });
};

export const useEditDayOrderQuery = (routineId: number) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (days: Day[]) => Promise.all(days.map(editDay)),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: [QueryKey.ROUTINE_DETAIL, routineId] })
    });
};

export const useAddDayQuery = (routineId: number) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (day: Day) => addDay(day),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: [QueryKey.ROUTINE_DETAIL, routineId] })
    });
};


export const useDeleteDayQuery = (routineId: number) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (id: number) => deleteDay(id),
        // Also on failure: a refused delete (e.g. the item has logged workouts) must show the item again
        onSettled: () => queryClient.invalidateQueries({ queryKey: [QueryKey.ROUTINE_DETAIL, routineId] })
    });
};
