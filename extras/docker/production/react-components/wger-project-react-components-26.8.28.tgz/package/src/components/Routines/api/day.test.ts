import { addDay, deleteDay, editDay } from "@/components/Routines/api/day";
import { Day } from "@/components/Routines/models/Day";
import axios from "axios";
import type { Mocked } from 'vitest';

vi.mock('axios');
const mockedAxios = axios as Mocked<typeof axios>;

describe('editDay', () => {

    const mockDayData = {
        id: 1,
        routine: 1,
        name: 'Test Day',
        description: 'A test day',
        order: 1,

        is_rest: false,
    };

    const testDay = Day.fromJson(mockDayData);
    testDay.name = 'Test Day';

    beforeEach(() => {
        // Reset mocks before each test
        vi.clearAllMocks();
    });

    test('should update a day and return the updated day', async () => {
        mockedAxios.patch.mockResolvedValue({ data: mockDayData });

        const updatedDay = await editDay(testDay);

        expect(axios.patch).toHaveBeenCalledTimes(1);
        expect(updatedDay).toEqual(Day.fromJson(mockDayData));
    });

    test('should PATCH the day id and the serialized day', async () => {
        mockedAxios.patch.mockResolvedValue({ data: mockDayData });

        await editDay(testDay);

        const [url, body] = mockedAxios.patch.mock.calls[0];
        expect(url).toMatch(/\/api\/v2\/day\/1\/$/);
        expect(body).toEqual({
            routine: 1,
            name: 'Test Day',
            description: 'A test day',
            order: 1,
            is_rest: false,
            need_logs_to_advance: false,
            type: 'custom',
            config: null,
        });
    });

    test('should handle errors gracefully', async () => {
        const errorMessage = 'Network Error';
        mockedAxios.patch.mockRejectedValue(new Error(errorMessage));

        await expect(editDay(testDay)).rejects.toThrow(errorMessage);
        expect(axios.patch).toHaveBeenCalledTimes(1);
    });
});


describe('addDay', () => {
    const mockDayData = {
        id: 1,
        routine: 1,
        name: 'Test Day',
        description: 'A test day',
        order: 1,

        is_rest: false,

        need_logs_to_advance: false,
    };

    const testDay = new Day({
        routineId: 1,
        name: 'Test Day',
        description: 'A test day',
        order: 1,
        isRest: false,
        needLogsToAdvance: false,
    });

    beforeEach(() => {
        vi.clearAllMocks();
    });

    test('should create a new day and return the created day', async () => {
        mockedAxios.post.mockResolvedValue({ data: mockDayData });

        const newDay = await addDay(testDay);

        expect(axios.post).toHaveBeenCalledTimes(1);
        expect(newDay).toEqual(Day.fromJson(mockDayData));
    });

    test('should POST the day in the snake_case format the API expects', async () => {
        mockedAxios.post.mockResolvedValue({ data: mockDayData });

        await addDay(testDay);

        const [url, body] = mockedAxios.post.mock.calls[0];
        expect(url).toMatch(/\/api\/v2\/day\/$/);
        expect(body).toEqual({
            routine: 1,
            name: 'Test Day',
            description: 'A test day',
            order: 1,
            is_rest: false,
            need_logs_to_advance: false,
            type: 'custom',
            config: null,
        });
    });

    test('should handle errors gracefully', async () => {
        const errorMessage = 'Network Error';
        mockedAxios.post.mockRejectedValue(new Error(errorMessage));

        await expect(addDay(testDay)).rejects.toThrow(errorMessage);
        expect(axios.post).toHaveBeenCalledTimes(1);
    });
});


describe('deleteDay', () => {
    const mockDayId = 1;

    beforeEach(() => {
        vi.clearAllMocks();
    });

    test('should delete a day', async () => {
        mockedAxios.delete.mockResolvedValue({ status: 204 }); // Assuming a successful delete returns 204 No Content

        await deleteDay(mockDayId);

        expect(axios.delete).toHaveBeenCalledTimes(1);
        expect(axios.delete).toHaveBeenCalledWith(
            expect.any(String),
            expect.any(Object)
        );
    });

    test('should handle errors gracefully', async () => {
        const errorMessage = 'Network Error';
        mockedAxios.delete.mockRejectedValue(new Error(errorMessage));

        await expect(deleteDay(mockDayId)).rejects.toThrow(errorMessage);
        expect(axios.delete).toHaveBeenCalledTimes(1);
    });
});