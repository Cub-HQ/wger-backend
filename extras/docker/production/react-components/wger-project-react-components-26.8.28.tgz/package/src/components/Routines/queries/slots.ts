import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Slot } from "@/components/Routines/models/Slot";
import { addSlot, deleteSlot, editSlot } from "@/components/Routines/api/slot";
import { QueryKey, } from "@/core/lib/consts";


export const useAddSlotQuery = (routineId: number) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (slot: Slot) => addSlot(slot),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: [QueryKey.ROUTINE_DETAIL, routineId] })
    });
};

export const useEditSlotQuery = (routineId: number) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (slot: Slot) => editSlot(slot),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: [QueryKey.ROUTINE_DETAIL, routineId] })
    });
};
export const useEditSlotsQuery = (routineId: number) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (slots: Slot[]) => Promise.all(slots.map(editSlot)),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: [QueryKey.ROUTINE_DETAIL, routineId] })
    });
};

export const useDeleteSlotQuery = (routineId: number) => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (slotId: number) => deleteSlot(slotId),
        // Also on failure: a refused delete (e.g. the item has logged workouts) must show the item again
        onSettled: () => queryClient.invalidateQueries({ queryKey: [QueryKey.ROUTINE_DETAIL, routineId] })
    });
};
