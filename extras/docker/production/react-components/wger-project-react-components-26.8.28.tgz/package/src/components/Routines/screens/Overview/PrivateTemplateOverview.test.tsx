import { QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor } from '@testing-library/react';
import { PrivateTemplateOverview } from "@/components/Routines/screens/Overview/PrivateTemplateOverview";
import { BrowserRouter } from "react-router-dom";
import { getPrivateTemplatesShallow } from "@/components/Routines/api/routine";
import { testQueryClient } from "@/tests/queryClient";
import { testPrivateTemplate1 } from "@/tests/workoutRoutinesTestData";
import type { Mock } from 'vitest';

vi.mock("@/components/Routines/api/routine");

describe("Smoke tests the PrivateTemplateOverview component", () => {

    beforeEach(() => {
        (getPrivateTemplatesShallow as Mock).mockResolvedValue([testPrivateTemplate1]);
    });

    test('renders all private templates', async () => {

        // Act
        render(
            <BrowserRouter>
                <QueryClientProvider client={testQueryClient}>
                    <PrivateTemplateOverview />
                </QueryClientProvider>
            </BrowserRouter>
        );
        // Assert
        await waitFor(() => expect(getPrivateTemplatesShallow).toHaveBeenCalledTimes(1));
        expect(await screen.findByText('private template 1')).toBeInTheDocument();
        expect(screen.getByText('routines.templates')).toBeInTheDocument();
    });
});
