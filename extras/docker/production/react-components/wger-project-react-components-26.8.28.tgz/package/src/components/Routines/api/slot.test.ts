import axios from "axios";
import { Slot } from "@/components/Routines/models/Slot";
import { addSlot, deleteSlot, editSlot } from "@/components/Routines/api/slot";
import { ApiPath } from "@/core/lib/consts";
import { makeHeader, makeUrl } from "@/core/lib/url";
import type { Mock } from 'vitest';

vi.mock('axios');

describe("Slot service tests", () => {
    const slotApiData = {
        day: 1,
        order: 1,
        comment: 'test',
        config: null
    };

    beforeEach(() => {
        vi.clearAllMocks();
    });

    test('Creates a new Slot', async () => {
        (axios.post as Mock).mockImplementation(() => Promise.resolve({ data: { id: 123, ...slotApiData } }));
        const slot = Slot.fromJson(slotApiData);

        const result = await addSlot(slot);

        // The body is asserted literally, using slot.toJson() here would compare the
        // serializer against itself
        expect(axios.post).toHaveBeenCalledWith(
            makeUrl(ApiPath.SLOT),
            { day: 1, order: 1, comment: 'test', config: null },
            { headers: makeHeader() }
        );
        expect(result).toStrictEqual(new Slot({ id: 123, dayId: 1, order: 1, comment: 'test', config: null }));
    });

    test('Update a Slot', async () => {
        (axios.patch as Mock).mockImplementation(() => Promise.resolve({
            data: {
                id: 123,
                ...slotApiData,
                comment: 'foo'
            }
        }));

        const slot = Slot.fromJson(slotApiData);
        slot.comment = 'foo';
        slot.id = 123;
        const result = await editSlot(slot);

        expect(axios.patch).toHaveBeenCalledWith(
            makeUrl(ApiPath.SLOT, { id: 123 }),
            { day: 1, order: 1, comment: 'foo', config: null },
            { headers: makeHeader() }
        );
        expect(result).toStrictEqual(new Slot({ id: 123, dayId: 1, order: 1, comment: 'foo', config: null }));
    });


    test('Delete a Slot', async () => {
        (axios.delete as Mock).mockImplementation(() => Promise.resolve({}));

        await deleteSlot(1);

        expect(axios.delete).toHaveBeenCalledWith(
            makeUrl(ApiPath.SLOT, { id: 1 }),
            { headers: makeHeader() }
        );
    });
});