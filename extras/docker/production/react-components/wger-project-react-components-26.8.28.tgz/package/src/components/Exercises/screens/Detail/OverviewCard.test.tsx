import { render, screen } from "@testing-library/react";
import { OverviewCard } from "@/components/Exercises/screens/Detail/OverviewCard";
import { Category } from "@/components/Exercises/models/category";
import { Equipment } from "@/components/Exercises/models/equipment";
import { Exercise } from "@/components/Exercises/models/exercise";
import { Language } from "@/components/Exercises/models/language";
import { Translation } from "@/components/Exercises/models/translation";
import React from "react";
import { BrowserRouter } from "react-router-dom";

describe("Test the exercise overview card component", () => {
    // Arrange
    const exerciseTranslation1 = new Translation({
        id: 111,
        uuid: "583281c7-2362-48e7-95d5-8fd6c455e0fb",
        name: "Squats",
        description: "Do a squat",
        descriptionSource: "Do a squat",
        language: 2,
    });
    const exerciseTranslation2 = new Translation({
        id: 9,
        uuid: "dae6f6ed-9408-4e62-a59a-1a33f4e8ab36",
        name: "Kniebeuge",
        description: "Kniebeuge machen",
        descriptionSource: "Kniebeuge machen",
        language: 1,
    });
    const category = new Category(10, "Abs");
    const equipment1 = new Equipment(10, "Kettlebell");
    const equipment2 = new Equipment(1, "Test 123");
    const exercise = new Exercise({
        id: 345,
        uuid: "c788d643-150a-4ac7-97ef-84643c6419bf",
        category: category,
        equipment: [equipment1, equipment2],
        translations: [exerciseTranslation1, exerciseTranslation2]
    });

    test("Render the overview card, no language selected -> use english", () => {
        // Act
        // since  OverviewCard renders a Link, we need to wrap in a BrowserRouter
        render(
            <BrowserRouter>
                <OverviewCard exercise={exercise} />
            </BrowserRouter>
        );

        // Assert
        expect(screen.getByText("Squats")).toBeInTheDocument();
        expect(screen.getByText("Abs")).toBeInTheDocument();
        expect(screen.getByText("Kettlebell")).toBeInTheDocument();
        expect(screen.getByText("Test 123")).toBeInTheDocument();
    });

    test("Render the overview card with an existing translation", async () => {
        // Arrange
        const language = new Language(1, "de", "Deutsch");

        // Act
        // since  OverviewCard renders a Link, we need to wrap in a BrowserRouter
        render(
            <BrowserRouter>
                <OverviewCard exercise={exercise} language={language} />
            </BrowserRouter>
        );

        // Assert
        expect(screen.queryByText("Squats")).not.toBeInTheDocument();
        expect(screen.getByText("Kniebeuge")).toBeInTheDocument();

        expect(screen.getByText("Abs")).toBeInTheDocument();
        expect(screen.getByText("Kettlebell")).toBeInTheDocument();
        expect(screen.getByText("Test 123")).toBeInTheDocument();
    });

    test("Render the overview card with a non existing translation -> fallback to english", async () => {
        // Arrange
        const language = new Language(3, "fr", "Français");

        // Act
        // since  OverviewCard renders a Link, we need to wrap in a BrowserRouter
        render(
            <BrowserRouter>
                <OverviewCard exercise={exercise} language={language} />
            </BrowserRouter>
        );

        // Assert
        expect(screen.queryByText("Kniebeuge")).not.toBeInTheDocument();
        expect(screen.getByText("Squats")).toBeInTheDocument();
        expect(screen.getByText("Abs")).toBeInTheDocument();
        expect(screen.getByText("Kettlebell")).toBeInTheDocument();
        expect(screen.getByText("Test 123")).toBeInTheDocument();
    });
});
