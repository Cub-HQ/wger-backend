import { Translation, TranslationAdapter } from "@/components/Exercises/models/translation";


describe("Exercise translation model tests", () => {

    // Arrange
    const e1 = new Translation({
        id: 2,
        uuid: "uuid",
        name: "a very long name that should be truncated",
        description: "description",
        language: 1,
        notes: [],
        aliases: [],
        authors: ['author1', 'author2', 'author3'],
    });

    test('name helper', () => {

        // Assert
        expect(e1.nameLong).toBe("a very long name that …");
    });

    test('adapter - from json', () => {

        // Assert
        const adapter = new TranslationAdapter();
        expect(adapter.fromJson({
            id: 2,
            uuid: "uuid",
            name: "a very long name that should be truncated",
            description: "description",
            language: 1,
            notes: [],
            aliases: [],
            description_source: '',

            author_history: ['author1', 'author2', 'author3']
        })).toStrictEqual(e1);
    });

    test('adapter - to json', () => {

        // Assert
        const adapter = new TranslationAdapter();
        expect(adapter.toJson(e1)).toStrictEqual({
            id: 2,
            uuid: "uuid",
            name: "a very long name that should be truncated",
            description: "description",
            language: 1,
            description_source: '',
        });
    });

    test('slug adapter', () => {
        // Arrange
        const e1 = new Translation({
            id: 2,
            uuid: "uuid",
            name: "Grüß Göttles",
            description: "description",
            language: 1,
        });

        // Assert
        expect(e1.nameSlug).toEqual('gruss-gottles');
    });
});

