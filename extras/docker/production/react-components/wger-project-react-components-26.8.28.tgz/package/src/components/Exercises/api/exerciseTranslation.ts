import { Exercise, ExerciseAdapter } from "@/components/Exercises/models/exercise";
import { Translation, TranslationAdapter } from "@/components/Exercises/models/translation";
import { ResponseType } from "@/core/api/responseType";
import { ENGLISH_LANGUAGE_CODE, LANGUAGE_SHORT_ENGLISH } from "@/core/lib/consts";
import { makeHeader, makeUrl } from "@/core/lib/url";
import { SearchLanguageFilter } from '@/core/ui/Widgets/SearchLanguageFilter';
import axios from 'axios';

export const EXERCISE_PATH = 'exercise';
export const EXERCISE_TRANSLATION_PATH = 'exercise-translation';


/*
 * Fetch all exercise translations for a given exercise base
 */
export const getExerciseTranslations = async (id: number): Promise<Translation[]> => {
    const url = makeUrl(EXERCISE_PATH, { query: { exercise: id } });
    const { data } = await axios.get<ResponseType<Translation>>(url, {
        headers: makeHeader(),
    });
    const adapter = new TranslationAdapter();
    return data.results.map(e => adapter.fromJson(e));
};


/*
 * Search for exercises by name using the exerciseinfo endpoint
 */
export const searchExerciseTranslations = async (
    name: string,
    languageCode: string = ENGLISH_LANGUAGE_CODE,
    languageFilter: SearchLanguageFilter = "current_english",
    exactMatch: boolean = false
): Promise<Exercise[]> => {
    const languages = languageFilter === "all" ? null : [languageCode];
    if (languages && languageFilter === "current_english" && languageCode !== LANGUAGE_SHORT_ENGLISH) {
        languages.push(LANGUAGE_SHORT_ENGLISH);
    }

    const url = makeUrl('exerciseinfo', {
        query: {
            ...(exactMatch ? { "name__exact": name } : { "name__search": name }),
            ...(languages ? { "language__code": languages.join(',') } : {}),
            limit: 50,
        }
    });

    try {
        const { data } = await axios.get<ResponseType<Exercise>>(url);

        if (!data || !data.results || !Array.isArray(data.results)) {
            return [];
        }

        const adapter = new ExerciseAdapter();
        return data.results.map((item: unknown) => adapter.fromJson(item));
    } catch {
        return [];
    }
};

/*
 * Create a new exercise translation
 */
export interface AddTranslationParams {
    exerciseId: number;
    languageId: number;
    name: string;
    author: string;
    descriptionSource: string;
}

export const addTranslation = async (params: AddTranslationParams): Promise<Translation> => {
    const { exerciseId, languageId, name, author, descriptionSource } = params;

    const url = makeUrl(EXERCISE_TRANSLATION_PATH);
    const baseData = {
        exercise: exerciseId,
        language: languageId,
        name: name,
        description_source: descriptionSource,

        license_author: author
    };
    const response = await axios.post(url, baseData, {
        headers: makeHeader(),
    });

    const adapter = new TranslationAdapter();
    return adapter.fromJson(response.data);
};

/*
 * Edit an existing exercise translation
 */
export interface EditTranslationParams extends AddTranslationParams {
    id: number;
}

export const editTranslation = async (data: EditTranslationParams): Promise<Translation> => {
    const { id, exerciseId, languageId, name, descriptionSource } = data;

    const url = makeUrl(EXERCISE_TRANSLATION_PATH, { id: id });
    const baseData = {
        exercise: exerciseId,
        language: languageId,
        name: name,
        description_source: descriptionSource,
    };
    const response = await axios.patch(
        url,
        baseData,
        { headers: makeHeader() }
    );

    const adapter = new TranslationAdapter();
    return adapter.fromJson(response.data);
};

/*
 * Delete an existing exercise translation
 */
export const deleteExerciseTranslation = async (id: number): Promise<number> => {
    const url = makeUrl(EXERCISE_TRANSLATION_PATH, { id: id });
    const response = await axios.delete(
        url,
        { headers: makeHeader() }
    );

    return response.status;
};