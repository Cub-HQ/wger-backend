// @vitest-environment jsdom
// (happy-dom has interaction quirks with MUI X DateTimePicker + Luxon that
// prevent the create-mode form submission. The rest of the suite runs on
// happy-dom for speed.)
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from '@testing-library/react';
import userEvent from "@testing-library/user-event";
import { MeasurementEntry } from "@/components/Measurements/models/Entry";
import {
    useAddGroupEntriesQuery,
    useAddMeasurementEntryQuery,
    useEditMeasurementEntryQuery
} from "@/components/Measurements/queries";
import type { Mock } from 'vitest';
import { MeasurementCategory } from "@/components/Measurements/models/Category";
import { EntryForm, GroupEntryForm } from "@/components/Measurements/widgets/EntryForm";
import i18n from "i18next";
import { TEST_MEASUREMENT_CATEGORY_1, TEST_MEASUREMENT_ENTRIES_1 } from "@/tests/measurementsTestData";

vi.mock("@/components/Measurements/api/bodyWeight");

vi.mock("@/components/Measurements/queries");


describe("Test the EntryForm component", () => {
    const queryClient = new QueryClient();
    let mutate = vi.fn();

    const renderComponent = (props: { entry?: MeasurementEntry, category: MeasurementCategory }) => {
        return render(
            <QueryClientProvider client={queryClient}>
                <EntryForm {...props} />
            </QueryClientProvider>
        );
    };

    beforeEach(() => {
        mutate = vi.fn();

        (useEditMeasurementEntryQuery as Mock).mockImplementation(() => ({
            mutate: mutate
        }));
        (useAddMeasurementEntryQuery as Mock).mockImplementation(() => ({
            mutate: mutate
        }));
    });

    afterEach(() => {
        // One test below fakes the clock, a failure there must not leak into the rest
        vi.useRealTimers();
    });

    test('Passing an existing entry renders its values in the form', () => {

        // Arrange
        const entry = TEST_MEASUREMENT_ENTRIES_1[0];

        // Act
        renderComponent({ entry, category: TEST_MEASUREMENT_CATEGORY_1 });

        // Assert
        expect(screen.getByDisplayValue('10')).toBeInTheDocument();
        expect(screen.getByDisplayValue('test note')).toBeInTheDocument();
        expect(screen.getAllByLabelText('date').length).toBeGreaterThan(0);
        expect(screen.getByLabelText('value')).toBeInTheDocument();
        expect(screen.getByLabelText('notes')).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'submit' })).toBeInTheDocument();
    });

    test('Editing an existing entry', async () => {

        // Arrange
        const entry = TEST_MEASUREMENT_ENTRIES_1[0];
        const user = userEvent.setup();

        // Act
        renderComponent({ entry, category: TEST_MEASUREMENT_CATEGORY_1 });
        const submitButton = screen.getByRole('button', { name: 'submit' });
        await user.clear(screen.getByLabelText('value'));
        await user.type(screen.getByLabelText('value'), '25');

        // Assert
        expect(submitButton).toBeInTheDocument();
        await user.click(submitButton);
        expect(mutate).toHaveBeenCalledWith(MeasurementEntry.clone(entry, { value: 25 }), expect.anything());
    });

    test('Creating a new entry', async () => {
        // Arrange
        const fakeNow = new Date(2023, 5, 18, 14, 30);
        vi.useFakeTimers({ now: fakeNow.getTime(), shouldAdvanceTime: true });
        const user = userEvent.setup({ advanceTimers: vi.advanceTimersByTime });

        // Act
        renderComponent({ category: TEST_MEASUREMENT_CATEGORY_1 });
        const valueInput = await screen.findByLabelText('value');
        const notesInput = await screen.findByLabelText('notes');
        const submitButton = screen.getByRole('button', { name: 'submit' });

        await user.clear(valueInput);
        await user.type(valueInput, '42.42');
        await user.clear(notesInput);
        await user.type(notesInput, 'The Shiba Inu is a breed of hunting dog from Japan.');

        // Assert
        expect(submitButton).toBeInTheDocument();
        await user.click(submitButton);
        expect(mutate).toHaveBeenCalledWith(new MeasurementEntry(
            null,
            TEST_MEASUREMENT_CATEGORY_1.id!,
            fakeNow,
            42.42,
            'The Shiba Inu is a breed of hunting dog from Japan.',
        ), expect.anything());

        vi.useRealTimers();
    });

    describe('Localization', () => {
        afterEach(() => {
            i18n.changeLanguage('en');
        });

        // The pickers always use the Australian locale, whatever the UI language
        test('renders date in Australian format in English', () => {
            i18n.changeLanguage('en');
            const entry = TEST_MEASUREMENT_ENTRIES_1[0];

            const { container } = renderComponent({ entry, category: TEST_MEASUREMENT_CATEGORY_1 });

            const picker = container.querySelector('.MuiPickersInputBase-root');
            expect(picker?.textContent).toContain('01/02/2023');
            // expect(picker?.textContent).toContain('08:00 AM');
        });

        test('renders date in Australian format in German', () => {
            i18n.changeLanguage('de');
            const entry = TEST_MEASUREMENT_ENTRIES_1[0];

            const { container } = renderComponent({ entry, category: TEST_MEASUREMENT_CATEGORY_1 });

            const picker = container.querySelector('.MuiPickersInputBase-root');
            expect(picker?.textContent).toContain('01/02/2023');
        });
    });
});

describe("Test the GroupEntryForm component", () => {
    const queryClient = new QueryClient();
    let mutate = vi.fn();

    const group = new MeasurementCategory('g-1', 'Blood pressure', 'mmHg', 'blood_pressure');
    group.children = [
        new MeasurementCategory('c-sys', 'Systolic', 'mmHg', 'blood_pressure_systolic', false, 'g-1'),
        new MeasurementCategory('c-dia', 'Diastolic', 'mmHg', 'blood_pressure_diastolic', false, 'g-1'),
    ];

    beforeEach(() => {
        mutate = vi.fn();
        (useAddGroupEntriesQuery as Mock).mockImplementation(() => ({
            mutate: mutate
        }));
    });

    test('renders one value field per child', () => {
        render(
            <QueryClientProvider client={queryClient}>
                <GroupEntryForm group={group} />
            </QueryClientProvider>
        );

        expect(screen.getByLabelText('measurements.metricTypes.blood_pressure_systolic (mmHg)')).toBeInTheDocument();
        expect(screen.getByLabelText('measurements.metricTypes.blood_pressure_diastolic (mmHg)')).toBeInTheDocument();
    });

    test('submits one entry per child with a shared date', async () => {
        const user = userEvent.setup();
        render(
            <QueryClientProvider client={queryClient}>
                <GroupEntryForm group={group} />
            </QueryClientProvider>
        );

        await user.type(screen.getByLabelText('measurements.metricTypes.blood_pressure_systolic (mmHg)'), '120');
        await user.type(screen.getByLabelText('measurements.metricTypes.blood_pressure_diastolic (mmHg)'), '80');
        await user.click(screen.getByRole('button', { name: 'submit' }));

        expect(mutate).toHaveBeenCalledTimes(1);
        const entries = mutate.mock.calls[0][0] as MeasurementEntry[];
        expect(entries.map(e => [e.category, e.value])).toStrictEqual([['c-sys', 120], ['c-dia', 80]]);
        expect(entries[0].date).toStrictEqual(entries[1].date);
    });

    test('does not submit while a value is missing', async () => {
        const user = userEvent.setup();
        render(
            <QueryClientProvider client={queryClient}>
                <GroupEntryForm group={group} />
            </QueryClientProvider>
        );

        await user.type(screen.getByLabelText('measurements.metricTypes.blood_pressure_systolic (mmHg)'), '120');
        await user.click(screen.getByRole('button', { name: 'submit' }));

        expect(mutate).not.toHaveBeenCalled();
    });
});
