import { Language } from "@/components/Exercises/models/language";
import { MIN_ACCOUNT_AGE_TO_TRUST } from "@/config";

export const ENGLISH_LANGUAGE_ID = 2;
export const ENGLISH_LANGUAGE_CODE = 'en';
export const ENGLISH_LANGUAGE_OBJ = new Language(ENGLISH_LANGUAGE_ID, ENGLISH_LANGUAGE_CODE, 'English');

export const MIN_ACCOUNT_AGE = MIN_ACCOUNT_AGE_TO_TRUST || 21;


// Fixture rows of the server, see wger/core/fixtures/setting_*_units.json
export const REP_UNIT_REPETITIONS = 1;
export const REP_UNIT_TILL_FAILURE = 2;
export const REP_UNIT_SECONDS = 3;
export const REP_UNIT_MINUTES = 4;
export const REP_UNIT_MILES = 5;
export const REP_UNIT_KILOMETERS = 6;
export const REP_UNIT_METERS = 8;

export const WEIGHT_UNIT_KG = 1;
export const WEIGHT_UNIT_LB = 2;
// Speeds share the weight unit table, they are never a load
export const WEIGHT_UNIT_KMH = 5;
export const WEIGHT_UNIT_MPH = 6;

export const EXERCISE_CATEGORY_CARDIO = 15;


/*
 * Keys used for the queries
 *
 * These don't have any meaning, they just need to be globally unique
 */
export enum QueryKey {

    // Routines
    ROUTINE_OVERVIEW = 'routine-overview',
    ROUTINE_DETAIL = 'routine-detail',
    SESSION_SEARCH = 'session-search',
    SESSIONS_FULL = 'sessions-full',
    ROUTINE_LOGS = 'routine-logs',
    ROUTINE_LOG_DATA = 'routine-log-data',
    ROUTINE_STATS = 'routine-stats',
    ROUTINES_ACTIVE = 'routines-active',
    ROUTINES_SHALLOW = 'routines-shallow',
    PRIVATE_TEMPLATES = 'private-templates',
    PUBLIC_TEMPLATES = 'public-templates',
    ROUTINE_WEIGHT_UNITS = 'weight-units',
    ROUTINE_REP_UNITS = 'rep-units',
    // Read-only Intervals.icu mirror (wger-gym#6)
    ENDURANCE_ENTRIES = 'endurance-entries',

    // Nutrition
    NUTRITIONAL_PLANS = 'nutritional-plans',
    NUTRITIONAL_PLAN = 'nutritional-plan',
    NUTRITIONAL_PLAN_DIARY = 'nutritional-plan-diary',
    NUTRITIONAL_PLAN_LAST = 'nutritional-plan-last',
    INGREDIENT = 'ingredient',

    // Profile
    PROFILE = 'profile',
    PERMISSION = 'permission',

    // Exercises
    EXERCISES = 'exercises',
    EXERCISE_VARIATIONS = 'variations',
    EXERCISE_DETAIL = 'detail',
    EXERCISE_TRANSLATION_SEARCH = 'exercise-translation-search',
    LANGUAGES = 'languages',
    CATEGORIES = 'categories',
    EQUIPMENT = 'equipment',
    MUSCLES = 'muscles',

    // Measurements (body weight is measurement data and shares these, see
    // the body weight queries)
    MEASUREMENTS = 'measurements',
    MEASUREMENTS_CATEGORIES = 'measurements-categories',
    MEASUREMENT_ENTRIES = 'measurement-entries',
    MEASUREMENT_BUCKETS = 'measurement-buckets',
    MEASUREMENT_VALUE_COUNTS = 'measurement-value-counts',

    // Nutrition (search)
    INGREDIENT_SEARCH = 'ingredient-search',

    // Trophies
    TROPHIES = 'trophies',
    USER_TROPHIES = 'user-trophies',
    USER_TROPHY_PROGRESSION = 'user-trophy-progression',
}

/*
 * List of API endpoints
 */
export enum ApiPath {

    // Nutrition
    MEAL = 'meal',
    MEAL_ITEM = 'mealitem',
    NUTRITIONAL_DIARY = 'nutritiondiary',
    INGREDIENTINFO_PATH = 'ingredientinfo',

    // Routines
    ROUTINE = 'routine',
    WEIGHT_CONFIG = 'weight-config',
    MAX_WEIGHT_CONFIG = 'max-weight-config',
    REPETITIONS_CONFIG = 'repetitions-config',
    MAX_REPS_CONFIG = 'max-repetitions-config',
    RIR_CONFIG = 'rir-config',
    MAX_RIR_CONFIG = 'max-rir-config',
    NR_OF_SETS_CONFIG = 'sets-config',
    MAX_NR_OF_SETS_CONFIG = 'max-sets-config',
    REST_CONFIG = 'rest-config',
    MAX_REST_CONFIG = 'max-rest-config',
    DAY = 'day',
    SLOT = 'slot',
    SLOT_ENTRY = 'slot-entry',
    SESSION = 'workoutsession',
    ENDURANCE_ENTRY = 'endurance-entry',

    WORKOUT_LOG = 'workoutlog',
    PRIVATE_TEMPLATE = 'templates',
    PUBLIC_TEMPLATE = 'public-templates',

    // Profile
    API_PROFILE_PATH = 'userprofile',

    // Trophies
    API_TROPHIES_PATH = 'trophy',
    API_USER_TROPHIES_PATH = 'user-trophy',
    API_USER_TROPHY_PROGRESSION_PATH = 'trophy/progress',
}


export const API_MAX_PAGE_SIZE = '999';

export const API_RESULTS_PAGE_SIZE = '100';

/*
 * List of colors to use in charts
 *
 * Use e.g. like LIST_OF_COLORS[key % LIST_OF_COLORS.length] so that there
 * are no errors when there are more categories than colors
 *
 * https://www.learnui.design/tools/data-color-picker.html#palette
 */
export const LIST_OF_COLORS8 = [
    "#2a4c7d",
    "#5b5291",
    "#8e5298",
    "#bf5092",
    "#e7537e",
    "#ff6461",
    "#ff813d",
    "#ffa600",
];
export const LIST_OF_COLORS5 = [
    "#2a4c7d",
    "#825298",
    "#d45089",
    "#ff6a59",
    "#ffa600",
];
export const LIST_OF_COLORS3 = [
    "#2a4c7d",
    "#d45089",
    "#ffa600",
];


export const PAGINATION_OPTIONS = {
    pageSizeOptions: [5, 10, 25, 50, 100],
    pageSize: 10,
};

export const LANGUAGE_SHORT_ENGLISH = 'en';

export const SNACKBAR_AUTO_HIDE_DURATION = 3000;

export const DEBOUNCE_ROUTINE_FORMS = 500;